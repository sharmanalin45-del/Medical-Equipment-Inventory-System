package pages;

import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginPage extends JFrame {

    public LoginPage() {

        setTitle("Medical Equipment Inventory System - Login");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);


        JLabel title = new JLabel("MEDICAL EQUIPMENT INVENTORY SYSTEM");
        title.setFont(new Font("Arial", Font.BOLD, 18));
        title.setBounds(70, 40, 400, 30);


        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(100, 120, 100, 30);


        JTextField usernameField = new JTextField();
        usernameField.setBounds(200, 120, 180, 30);


        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(100, 170, 100, 30);


        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(200, 170, 180, 30);


        JButton loginButton = new JButton("Login");
        loginButton.setBounds(190, 230, 120, 35);


        JButton signUpButton = new JButton("Sign Up");
        signUpButton.setBounds(100, 300, 120, 35);


        JButton forgotPasswordButton =
                new JButton("Forgot Password");

        forgotPasswordButton.setBounds(260, 300, 150, 35);


        // LOGIN BUTTON

        loginButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                try {

                    Connection connection = DBConnection.getConnection();

                    String query =
                            "SELECT * FROM users WHERE username=? AND password=?";

                    PreparedStatement statement =
                            connection.prepareStatement(query);

                    statement.setString(
                            1,
                            usernameField.getText()
                    );

                    statement.setString(
                            2,
                            new String(passwordField.getPassword())
                    );


                    ResultSet result = statement.executeQuery();


                    if (result.next()) {

                        String role = result.getString("role");

                        JOptionPane.showMessageDialog(
                                null,
                                "Login Successful!\nRole: " + role
                        );

                        new DashboardPage(role);

                        dispose();

                    } else {

                        JOptionPane.showMessageDialog(
                                null,
                                "Invalid Username or Password"
                        );

                    }


                    connection.close();

                } catch (Exception ex) {

                    JOptionPane.showMessageDialog(
                            null,
                            ex.getMessage()
                    );

                }

            }

        });


        // SIGN UP BUTTON

        signUpButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                new SignUpPage();

                dispose();

            }

        });


        // FORGOT PASSWORD BUTTON

        forgotPasswordButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(ActionEvent e) {

                        new ForgotPasswordPage();

                        dispose();

                    }

                }
        );


        panel.add(title);

        panel.add(usernameLabel);
        panel.add(usernameField);

        panel.add(passwordLabel);
        panel.add(passwordField);

        panel.add(loginButton);

        panel.add(signUpButton);
        panel.add(forgotPasswordButton);


        add(panel);

        setVisible(true);
    }


    public static void main(String[] args) {

        new LoginPage();

    }
}