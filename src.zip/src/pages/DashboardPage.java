package pages;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DashboardPage extends JPanel {

    String role;
    CardLayout cardLayout;
    JPanel contentPanel;

    public DashboardPage(
            String role,
            CardLayout cardLayout,
            JPanel contentPanel
    ) {

        this.role = role;
        this.cardLayout = cardLayout;
        this.contentPanel = contentPanel;

        setLayout(null);

        setBackground(
                new Color(245, 247, 246)
        );


        JLabel title =
                new JLabel(
                        "MEDICAL EQUIPMENT INVENTORY SYSTEM"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );

        title.setBounds(
                170,
                30,
                500,
                40
        );


        JLabel welcome =
                new JLabel(
                        "Welcome to Dashboard - " + role
                );

        welcome.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        18
                )
        );

        welcome.setBounds(
                220,
                90,
                300,
                30
        );


        JButton addButton =
                new JButton(
                        "Add Equipment"
                );

        addButton.setBounds(
                100,
                160,
                200,
                50
        );


        JButton viewButton =
                new JButton(
                        "View Equipment"
                );

        viewButton.setBounds(
                400,
                160,
                200,
                50
        );


        JButton updateButton =
                new JButton(
                        "Update Equipment"
                );

        updateButton.setBounds(
                100,
                250,
                200,
                50
        );


        JButton deleteButton =
                new JButton(
                        "Delete Equipment"
                );

        deleteButton.setBounds(
                400,
                250,
                200,
                50
        );


        JButton maintenanceButton =
                new JButton(
                        "Maintenance"
                );

        maintenanceButton.setBounds(
                250,
                340,
                200,
                50
        );


        JButton logoutButton =
                new JButton(
                        "Logout"
                );

        logoutButton.setBounds(
                300,
                440,
                100,
                40
        );


        add(title);
        add(welcome);

        add(addButton);
        add(viewButton);

        add(updateButton);
        add(deleteButton);

        add(maintenanceButton);

        add(logoutButton);


        // STAFF RESTRICTIONS

        if (role.equalsIgnoreCase("Staff")) {

            addButton.setEnabled(false);

            updateButton.setEnabled(false);

            deleteButton.setEnabled(false);

        }


        // ADD EQUIPMENT

        addButton.addActionListener(
                e -> {

                    cardLayout.show(
                            contentPanel,
                            "addEquipment"
                    );

                }
        );


        // VIEW EQUIPMENT

        viewButton.addActionListener(
                e -> {

                    cardLayout.show(
                            contentPanel,
                            "viewEquipment"
                    );

                }
        );


        // UPDATE EQUIPMENT

        updateButton.addActionListener(
                e -> {

                    cardLayout.show(
                            contentPanel,
                            "updateEquipment"
                    );

                }
        );


        // DELETE EQUIPMENT

        deleteButton.addActionListener(
                e -> {

                    cardLayout.show(
                            contentPanel,
                            "deleteEquipment"
                    );

                }
        );


        // MAINTENANCE

        maintenanceButton.addActionListener(
                e -> {

                    cardLayout.show(
                            contentPanel,
                            "maintenance"
                    );

                }
        );


        // LOGOUT

        logoutButton.addActionListener(
                e -> {

                    System.exit(0);

                }
        );

    }

}