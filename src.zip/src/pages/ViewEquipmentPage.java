package pages;

import database.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewEquipmentPage extends JFrame {

    JTable table;
    JButton backButton;

    String role;

    public ViewEquipmentPage(String role) {

        this.role = role;

        setTitle("Medical Equipment Inventory System - View Equipment");
        setSize(1000, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(null);


        JLabel title = new JLabel("VIEW EQUIPMENT");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBounds(400, 30, 250, 40);
        add(title);


        String[] columns = {
                "ID",
                "Equipment Name",
                "Category",
                "Total Quantity",
                "Under Maintenance",
                "Available Quantity",
                "Price",
                "Supplier"
        };


        DefaultTableModel model =
                new DefaultTableModel(columns, 0);

        table = new JTable(model);

        JScrollPane scrollPane =
                new JScrollPane(table);

        scrollPane.setBounds(30, 100, 920, 280);

        add(scrollPane);


        try {

            Connection connection =
                    DBConnection.getConnection();


            String query =
                    "SELECT e.id, e.name, e.category, e.quantity, " +
                            "e.price, e.supplier, " +

                            "COALESCE(SUM(CASE " +
                            "WHEN m.status != 'Completed' " +
                            "THEN m.maintenance_quantity " +
                            "ELSE 0 END), 0) AS under_maintenance " +

                            "FROM equipment e " +

                            "LEFT JOIN maintenance m " +
                            "ON e.id = m.equipment_id " +

                            "GROUP BY e.id, e.name, e.category, " +
                            "e.quantity, e.price, e.supplier";


            PreparedStatement statement =
                    connection.prepareStatement(query);


            ResultSet result =
                    statement.executeQuery();


            while (result.next()) {

                int id =
                        result.getInt("id");

                String name =
                        result.getString("name");

                String category =
                        result.getString("category");

                int quantity =
                        result.getInt("quantity");

                int underMaintenance =
                        result.getInt(
                                "under_maintenance"
                        );

                int availableQuantity =
                        quantity - underMaintenance;

                double price =
                        result.getDouble("price");

                String supplier =
                        result.getString("supplier");


                model.addRow(
                        new Object[]{

                                id,
                                name,
                                category,
                                quantity,
                                underMaintenance,
                                availableQuantity,
                                price,
                                supplier
                        }
                );
            }


            connection.close();


        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error: " + e.getMessage()
            );
        }


        backButton =
                new JButton("Back");

        backButton.setBounds(
                450,
                420,
                100,
                40
        );


        backButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent e) {

                        new DashboardPage(role);

                        dispose();
                    }
                }
        );


        add(backButton);


        setVisible(true);
    }


    public static void main(String[] args) {

        new ViewEquipmentPage("Admin");

    }
}