package pages;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    CardLayout cardLayout;
    JPanel contentPanel;

    public MainFrame() {

        setTitle("Medical Equipment Inventory System");

        setSize(1200, 700);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);


        // MAIN PANEL

        JPanel mainPanel = new JPanel(
                new BorderLayout()
        );


        // COLORS

        Color sidebarColor =
                new Color(30, 70, 65);

        Color backgroundColor =
                new Color(245, 247, 246);

        Color buttonColor =
                new Color(45, 95, 88);


        // =========================
        // SIDEBAR
        // =========================

        JPanel sidebar = new JPanel();

        sidebar.setLayout(null);

        sidebar.setPreferredSize(
                new Dimension(220, 700)
        );

        sidebar.setBackground(
                sidebarColor
        );


        // LOGO

        JLabel logo =
                new JLabel("MEDICAL");

        logo.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );

        logo.setForeground(
                Color.WHITE
        );

        logo.setBounds(
                40,
                30,
                160,
                35
        );


        JLabel logo2 =
                new JLabel("EQUIPMENT SYSTEM");

        logo2.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        logo2.setForeground(
                new Color(
                        200,
                        220,
                        215
                )
        );

        logo2.setBounds(
                40,
                60,
                170,
                30
        );


        // =========================
        // SIDEBAR BUTTONS
        // =========================

        JButton dashboardButton =
                new JButton("Dashboard");

        dashboardButton.setBounds(
                20,
                130,
                180,
                45
        );


        JButton equipmentButton =
                new JButton("Equipment");

        equipmentButton.setBounds(
                20,
                190,
                180,
                45
        );


        JButton maintenanceButton =
                new JButton("Maintenance");

        maintenanceButton.setBounds(
                20,
                250,
                180,
                45
        );


        JButton logoutButton =
                new JButton("Logout");

        logoutButton.setBounds(
                20,
                570,
                180,
                45
        );


        // =========================
        // BUTTON DESIGN
        // =========================

        JButton[] sidebarButtons = {

                dashboardButton,
                equipmentButton,
                maintenanceButton,
                logoutButton

        };


        for (JButton button : sidebarButtons) {

            button.setBackground(
                    buttonColor
            );

            button.setForeground(
                    Color.WHITE
            );

            button.setFocusPainted(
                    false
            );

            button.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            15
                    )
            );

        }


        // =========================
        // ADD TO SIDEBAR
        // =========================

        sidebar.add(logo);

        sidebar.add(logo2);

        sidebar.add(dashboardButton);

        sidebar.add(equipmentButton);

        sidebar.add(maintenanceButton);

        sidebar.add(logoutButton);


        // =========================
        // CONTENT PANEL
        // =========================

        cardLayout =
                new CardLayout();

        contentPanel =
                new JPanel(
                        cardLayout
                );

        contentPanel.setBackground(
                backgroundColor
        );


        // =========================
        // DASHBOARD PANEL
        // =========================

        JPanel dashboardPanel =
                createDashboardPanel();

        contentPanel.add(
                dashboardPanel,
                "Dashboard"
        );


        // =========================
        // EQUIPMENT PANEL
        // =========================

        EquipmentPanel equipmentPanel =
                new EquipmentPanel(
                        cardLayout,
                        contentPanel
                );

        contentPanel.add(
                equipmentPanel,
                "Equipment"
        );


        // =========================
        // ADD EQUIPMENT PANEL
        // =========================

        AddEquipmentPage addEquipmentPage =
                new AddEquipmentPage(
                        cardLayout,
                        contentPanel
                );

        contentPanel.add(
                addEquipmentPage,
                "addEquipment"
        );


        // UPDATE EQUIPMENT

        UpdateEquipmentPage updateEquipmentPage =
                new UpdateEquipmentPage(
                        cardLayout,
                        contentPanel
                );

        contentPanel.add(
                updateEquipmentPage,
                "updateEquipment"
        );


        // =========================
        // MAINTENANCE PANEL
        // =========================

        JPanel maintenancePanel =
                createMaintenancePanel();

        contentPanel.add(
                maintenancePanel,
                "Maintenance"
        );


        // =========================
        // SIDEBAR BUTTON ACTIONS
        // =========================

        dashboardButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "Dashboard"
            );

        });


        equipmentButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "Equipment"
            );

        });


        maintenanceButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "Maintenance"
            );

        });


        logoutButton.addActionListener(e -> {

            int choice =
                    JOptionPane.showConfirmDialog(
                            this,
                            "Are you sure you want to logout?",
                            "Logout",
                            JOptionPane.YES_NO_OPTION
                    );

            if (choice ==
                    JOptionPane.YES_OPTION) {

                System.exit(0);

            }

        });


        // =========================
        // ADD MAIN COMPONENTS
        // =========================

        mainPanel.add(
                sidebar,
                BorderLayout.WEST
        );

        mainPanel.add(
                contentPanel,
                BorderLayout.CENTER
        );


        add(mainPanel);


        // =========================
        // SHOW DASHBOARD FIRST
        // =========================

        cardLayout.show(
                contentPanel,
                "Dashboard"
        );


        setVisible(true);

    }


    // =========================
    // DASHBOARD PANEL
    // =========================

    public JPanel createDashboardPanel() {

        JPanel dashboard =
                new JPanel();

        dashboard.setLayout(null);

        dashboard.setBackground(
                new Color(
                        245,
                        247,
                        246
                )
        );


        JLabel title =
                new JLabel("DASHBOARD");

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30
                )
        );

        title.setBounds(
                60,
                50,
                400,
                50
        );

        dashboard.add(title);


        JLabel subtitle =
                new JLabel(
                        "Medical Equipment Inventory Overview"
                );

        subtitle.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        20
                )
        );

        subtitle.setBounds(
                60,
                105,
                500,
                35
        );

        dashboard.add(subtitle);


        // =========================
        // DASHBOARD CARDS
        // =========================

        JPanel totalEquipment =
                createCard(
                        "TOTAL EQUIPMENT",
                        "0"
                );

        totalEquipment.setBounds(
                60,
                200,
                190,
                160
        );

        dashboard.add(
                totalEquipment
        );


        JPanel totalQuantity =
                createCard(
                        "TOTAL QUANTITY",
                        "0"
                );

        totalQuantity.setBounds(
                280,
                200,
                190,
                160
        );

        dashboard.add(
                totalQuantity
        );


        JPanel maintenance =
                createCard(
                        "UNDER MAINTENANCE",
                        "0"
                );

        maintenance.setBounds(
                500,
                200,
                190,
                160
        );

        dashboard.add(
                maintenance
        );


        JPanel available =
                createCard(
                        "AVAILABLE QUANTITY",
                        "0"
                );

        available.setBounds(
                720,
                200,
                190,
                160
        );

        dashboard.add(
                available
        );


        return dashboard;

    }


    // =========================
    // DASHBOARD CARD
    // =========================

    public JPanel createCard(
            String title,
            String value
    ) {

        JPanel card =
                new JPanel();

        card.setLayout(null);

        card.setBackground(
                Color.WHITE
        );

        card.setBorder(
                BorderFactory.createLineBorder(
                        new Color(
                                210,
                                210,
                                210
                        )
                )
        );


        JLabel cardTitle =
                new JLabel(title);

        cardTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        cardTitle.setForeground(
                new Color(
                        80,
                        80,
                        80
                )
        );

        cardTitle.setBounds(
                15,
                30,
                170,
                30
        );

        card.add(cardTitle);


        JLabel cardValue =
                new JLabel(value);

        cardValue.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        36
                )
        );

        cardValue.setBounds(
                15,
                75,
                150,
                50
        );

        card.add(cardValue);


        return card;

    }


    // =========================
    // MAINTENANCE PANEL
    // =========================

    public JPanel createMaintenancePanel() {

        JPanel maintenance =
                new JPanel();

        maintenance.setLayout(null);

        maintenance.setBackground(
                new Color(
                        245,
                        247,
                        246
                )
        );


        JLabel title =
                new JLabel(
                        "MAINTENANCE MANAGEMENT"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30
                )
        );

        title.setBounds(
                250,
                250,
                600,
                60
        );

        maintenance.add(title);


        return maintenance;

    }


    public static void main(
            String[] args
    ) {

        SwingUtilities.invokeLater(() -> {

            new MainFrame();

        });

    }

}