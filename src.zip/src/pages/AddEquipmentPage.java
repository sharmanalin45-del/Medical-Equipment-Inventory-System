package pages;

import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddEquipmentPage extends JPanel {

    JTextField idField;
    JTextField nameField;
    JTextField categoryField;
    JTextField quantityField;
    JTextField priceField;
    JTextField supplierField;

    JButton addButton;
    JButton backButton;

    CardLayout cardLayout;
    JPanel contentPanel;

    public AddEquipmentPage(CardLayout cardLayout, JPanel contentPanel) {

        this.cardLayout = cardLayout;
        this.contentPanel = contentPanel;

        setLayout(null);

        setBackground(new Color(245, 247, 246));


        JLabel title = new JLabel("ADD EQUIPMENT");

        title.setFont(
                new Font("Arial", Font.BOLD, 30)
        );

        title.setBounds(
                350,
                60,
                400,
                50
        );

        add(title);


        JLabel idLabel =
                new JLabel("Equipment ID:");

        idLabel.setBounds(
                220,
                140,
                150,
                30
        );

        add(idLabel);


        idField = new JTextField();

        idField.setBounds(
                400,
                140,
                250,
                35
        );

        add(idField);


        JLabel nameLabel =
                new JLabel("Equipment Name:");

        nameLabel.setBounds(
                220,
                190,
                150,
                30
        );

        add(nameLabel);


        nameField = new JTextField();

        nameField.setBounds(
                400,
                190,
                250,
                35
        );

        add(nameField);


        JLabel categoryLabel =
                new JLabel("Category:");

        categoryLabel.setBounds(
                220,
                240,
                150,
                30
        );

        add(categoryLabel);


        categoryField = new JTextField();

        categoryField.setBounds(
                400,
                240,
                250,
                35
        );

        add(categoryField);


        JLabel quantityLabel =
                new JLabel("Quantity:");

        quantityLabel.setBounds(
                220,
                290,
                150,
                30
        );

        add(quantityLabel);


        quantityField = new JTextField();

        quantityField.setBounds(
                400,
                290,
                250,
                35
        );

        add(quantityField);


        JLabel priceLabel =
                new JLabel("Price:");

        priceLabel.setBounds(
                220,
                340,
                150,
                30
        );

        add(priceLabel);


        priceField = new JTextField();

        priceField.setBounds(
                400,
                340,
                250,
                35
        );

        add(priceField);


        JLabel supplierLabel =
                new JLabel("Supplier:");

        supplierLabel.setBounds(
                220,
                390,
                150,
                30
        );

        add(supplierLabel);


        supplierField = new JTextField();

        supplierField.setBounds(
                400,
                390,
                250,
                35
        );

        add(supplierField);


        addButton =
                new JButton("Add Equipment");

        addButton.setBounds(
                320,
                470,
                160,
                45
        );

        add(addButton);


        backButton =
                new JButton("Back");

        backButton.setBounds(
                500,
                470,
                120,
                45
        );

        add(backButton);


        Color buttonColor =
                new Color(45, 95, 88);


        JButton[] buttons = {
                addButton,
                backButton
        };


        for (JButton button : buttons) {

            button.setBackground(buttonColor);

            button.setForeground(Color.WHITE);

            button.setFocusPainted(false);

            button.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            15
                    )
            );
        }


        addButton.addActionListener(e -> {

            try {

                if (idField.getText().isEmpty()
                        || nameField.getText().isEmpty()
                        || categoryField.getText().isEmpty()
                        || quantityField.getText().isEmpty()
                        || priceField.getText().isEmpty()
                        || supplierField.getText().isEmpty()) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Please fill all fields!"
                    );

                    return;
                }


                int id =
                        Integer.parseInt(
                                idField.getText()
                        );

                String name =
                        nameField.getText();

                String category =
                        categoryField.getText();

                int quantity =
                        Integer.parseInt(
                                quantityField.getText()
                        );

                double price =
                        Double.parseDouble(
                                priceField.getText()
                        );

                String supplier =
                        supplierField.getText();


                Connection connection =
                        DBConnection.getConnection();


                String query =
                        "INSERT INTO equipment VALUES (?, ?, ?, ?, ?, ?)";


                PreparedStatement statement =
                        connection.prepareStatement(query);


                statement.setInt(
                        1,
                        id
                );

                statement.setString(
                        2,
                        name
                );

                statement.setString(
                        3,
                        category
                );

                statement.setInt(
                        4,
                        quantity
                );

                statement.setDouble(
                        5,
                        price
                );

                statement.setString(
                        6,
                        supplier
                );


                statement.executeUpdate();


                JOptionPane.showMessageDialog(
                        null,
                        "Equipment Added Successfully!"
                );


                idField.setText("");

                nameField.setText("");

                categoryField.setText("");

                quantityField.setText("");

                priceField.setText("");

                supplierField.setText("");


                connection.close();

            } catch (NumberFormatException ex) {

                JOptionPane.showMessageDialog(
                        null,
                        "ID, Quantity and Price must be numbers!"
                );

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        null,
                        "Error: " + ex.getMessage()
                );

            }

        });


        backButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "Equipment"
            );

        });

    }

}