package pages;

import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class UpdateMaintenancePage extends JFrame {

    public UpdateMaintenancePage(String role) {

        setTitle("Update Maintenance");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);


        JLabel title = new JLabel("UPDATE MAINTENANCE RECORD");

        title.setFont(
                new Font("Arial", Font.BOLD, 22)
        );

        title.setBounds(150, 30, 350, 40);


        JLabel idLabel =
                new JLabel("Maintenance ID:");

        idLabel.setBounds(
                100, 100, 130, 30
        );


        JTextField idField =
                new JTextField();

        idField.setBounds(
                250, 100, 200, 30
        );


        JLabel equipmentIdLabel =
                new JLabel("Equipment ID:");

        equipmentIdLabel.setBounds(
                100, 150, 130, 30
        );


        JTextField equipmentIdField =
                new JTextField();

        equipmentIdField.setBounds(
                250, 150, 200, 30
        );


        JLabel equipmentNameLabel =
                new JLabel("Equipment Name:");

        equipmentNameLabel.setBounds(
                100, 200, 130, 30
        );


        JTextField equipmentNameField =
                new JTextField();

        equipmentNameField.setBounds(
                250, 200, 200, 30
        );


        JLabel statusLabel =
                new JLabel("Status:");

        statusLabel.setBounds(
                100, 250, 130, 30
        );


        String[] statusList = {
                "Pending",
                "In Progress",
                "Completed"
        };


        JComboBox<String> statusBox =
                new JComboBox<>(statusList);

        statusBox.setBounds(
                250, 250, 200, 30
        );


        JLabel dateLabel =
                new JLabel("Maintenance Date:");

        dateLabel.setBounds(
                100, 300, 140, 30
        );


        JTextField dateField =
                new JTextField();

        dateField.setBounds(
                250, 300, 200, 30
        );


        JLabel descriptionLabel =
                new JLabel("Description:");

        descriptionLabel.setBounds(
                100, 350, 130, 30
        );


        JTextArea descriptionArea =
                new JTextArea();


        JScrollPane scrollPane =
                new JScrollPane(descriptionArea);

        scrollPane.setBounds(
                250, 350, 200, 70
        );


        JButton updateButton =
                new JButton("Update");

        updateButton.setBounds(
                170, 470, 120, 40
        );


        JButton backButton =
                new JButton("Back");

        backButton.setBounds(
                330, 470, 120, 40
        );


        panel.add(title);

        panel.add(idLabel);
        panel.add(idField);

        panel.add(equipmentIdLabel);
        panel.add(equipmentIdField);

        panel.add(equipmentNameLabel);
        panel.add(equipmentNameField);

        panel.add(statusLabel);
        panel.add(statusBox);

        panel.add(dateLabel);
        panel.add(dateField);

        panel.add(descriptionLabel);
        panel.add(scrollPane);

        panel.add(updateButton);
        panel.add(backButton);

        add(panel);


        // UPDATE BUTTON

        updateButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent e) {

                        try {

                            Connection connection =
                                    DBConnection.getConnection();


                            String query =
                                    "UPDATE maintenance " +
                                            "SET equipment_id=?, " +
                                            "equipment_name=?, " +
                                            "status=?, " +
                                            "maintenance_date=?, " +
                                            "description=? " +
                                            "WHERE maintenance_id=?";


                            PreparedStatement statement =
                                    connection.prepareStatement(query);


                            statement.setInt(
                                    1,
                                    Integer.parseInt(
                                            equipmentIdField.getText()
                                    )
                            );


                            statement.setString(
                                    2,
                                    equipmentNameField.getText()
                            );


                            statement.setString(
                                    3,
                                    statusBox
                                            .getSelectedItem()
                                            .toString()
                            );


                            statement.setString(
                                    4,
                                    dateField.getText()
                            );


                            statement.setString(
                                    5,
                                    descriptionArea.getText()
                            );


                            statement.setInt(
                                    6,
                                    Integer.parseInt(
                                            idField.getText()
                                    )
                            );


                            int rows =
                                    statement.executeUpdate();


                            if (rows > 0) {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Maintenance Record Updated Successfully!"
                                );

                            } else {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Maintenance ID Not Found!"
                                );

                            }


                            connection.close();


                        } catch (Exception ex) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    ex.getMessage()
                            );

                        }

                    }

                }
        );


        // BACK BUTTON

        backButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent e) {

                        new MaintenancePage(role);

                        dispose();

                    }

                }
        );


        setVisible(true);
    }
}