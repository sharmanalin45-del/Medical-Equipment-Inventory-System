package pages;

import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddMaintenancePage extends JFrame {

    public AddMaintenancePage(String role) {

        setTitle("Add Maintenance");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);


        JLabel title = new JLabel("ADD MAINTENANCE RECORD");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(170, 30, 300, 40);


        JLabel equipmentIdLabel = new JLabel("Equipment ID:");
        equipmentIdLabel.setBounds(100, 100, 120, 30);

        JTextField equipmentIdField = new JTextField();
        equipmentIdField.setBounds(250, 100, 200, 30);


        JLabel equipmentNameLabel = new JLabel("Equipment Name:");
        equipmentNameLabel.setBounds(100, 145, 120, 30);

        JTextField equipmentNameField = new JTextField();
        equipmentNameField.setBounds(250, 145, 200, 30);


        JLabel quantityLabel = new JLabel("Maintenance Quantity:");
        quantityLabel.setBounds(100, 190, 150, 30);

        JTextField quantityField = new JTextField();
        quantityField.setBounds(250, 190, 200, 30);


        JLabel statusLabel = new JLabel("Status:");
        statusLabel.setBounds(100, 235, 120, 30);

        String[] statusList = {
                "Pending",
                "In Progress",
                "Completed"
        };

        JComboBox<String> statusBox =
                new JComboBox<>(statusList);

        statusBox.setBounds(250, 235, 200, 30);


        JLabel dateLabel = new JLabel("Maintenance Date:");
        dateLabel.setBounds(100, 280, 140, 30);

        JTextField dateField = new JTextField();
        dateField.setBounds(250, 280, 200, 30);


        JLabel descriptionLabel =
                new JLabel("Description:");

        descriptionLabel.setBounds(100, 325, 120, 30);


        JTextArea descriptionArea = new JTextArea();

        JScrollPane scrollPane =
                new JScrollPane(descriptionArea);

        scrollPane.setBounds(250, 325, 200, 70);


        JButton addButton =
                new JButton("Add Maintenance");

        addButton.setBounds(160, 450, 170, 40);


        JButton backButton =
                new JButton("Back");

        backButton.setBounds(350, 450, 100, 40);


        addButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent e) {

                        try {

                            int equipmentId =
                                    Integer.parseInt(
                                            equipmentIdField.getText()
                                    );

                            int maintenanceQuantity =
                                    Integer.parseInt(
                                            quantityField.getText()
                                    );


                            if (maintenanceQuantity <= 0) {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Maintenance Quantity must be greater than 0"
                                );

                                return;

                            }


                            Connection connection =
                                    DBConnection.getConnection();


                            String query =
                                    "INSERT INTO maintenance " +
                                            "(equipment_id, equipment_name, maintenance_quantity, status, maintenance_date, description) " +
                                            "VALUES (?, ?, ?, ?, ?, ?)";


                            PreparedStatement statement =
                                    connection.prepareStatement(query);


                            statement.setInt(
                                    1,
                                    equipmentId
                            );


                            statement.setString(
                                    2,
                                    equipmentNameField.getText()
                            );


                            statement.setInt(
                                    3,
                                    maintenanceQuantity
                            );


                            statement.setString(
                                    4,
                                    statusBox.getSelectedItem()
                                            .toString()
                            );


                            statement.setString(
                                    5,
                                    dateField.getText()
                            );


                            statement.setString(
                                    6,
                                    descriptionArea.getText()
                            );


                            statement.executeUpdate();


                            JOptionPane.showMessageDialog(
                                    null,
                                    "Maintenance Record Added Successfully!"
                            );


                            equipmentIdField.setText("");
                            equipmentNameField.setText("");
                            quantityField.setText("");
                            dateField.setText("");
                            descriptionArea.setText("");


                            statement.close();
                            connection.close();


                        } catch (NumberFormatException ex) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Please enter valid numeric values for Equipment ID and Quantity"
                            );

                        } catch (Exception ex) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    ex.getMessage()
                            );

                        }

                    }

                }
        );


        backButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent e) {

                        new MaintenancePage(role);

                        dispose();

                    }

                }
        );


        panel.add(title);

        panel.add(equipmentIdLabel);
        panel.add(equipmentIdField);

        panel.add(equipmentNameLabel);
        panel.add(equipmentNameField);

        panel.add(quantityLabel);
        panel.add(quantityField);

        panel.add(statusLabel);
        panel.add(statusBox);

        panel.add(dateLabel);
        panel.add(dateField);

        panel.add(descriptionLabel);
        panel.add(scrollPane);

        panel.add(addButton);
        panel.add(backButton);


        add(panel);

        setVisible(true);
    }
}