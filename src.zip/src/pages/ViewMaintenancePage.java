package pages;

import database.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewMaintenancePage extends JPanel {

    CardLayout cardLayout;
    JPanel contentPanel;

    JTable table;
    DefaultTableModel model;

    JButton refreshButton;
    JButton backButton;

    public ViewMaintenancePage(
            CardLayout cardLayout,
            JPanel contentPanel
    ) {

        this.cardLayout = cardLayout;
        this.contentPanel = contentPanel;

        setLayout(new BorderLayout());

        setBackground(
                new Color(245, 247, 246)
        );


        // TITLE PANEL

        JPanel topPanel = new JPanel();

        topPanel.setBackground(
                new Color(245, 247, 246)
        );


        JLabel title =
                new JLabel(
                        "VIEW MAINTENANCE"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        topPanel.add(title);

        add(
                topPanel,
                BorderLayout.NORTH
        );


        // TABLE

        String[] columns = {

                "Maintenance ID",
                "Equipment ID",
                "Maintenance Date",
                "Description",
                "Status"

        };


        model =
                new DefaultTableModel(
                        columns,
                        0
                );


        table =
                new JTable(model);


        JScrollPane scrollPane =
                new JScrollPane(table);


        add(
                scrollPane,
                BorderLayout.CENTER
        );


        // BUTTON PANEL

        JPanel bottomPanel =
                new JPanel();

        bottomPanel.setBackground(
                new Color(245, 247, 246)
        );


        refreshButton =
                new JButton(
                        "Refresh"
                );


        backButton =
                new JButton(
                        "Back"
                );


        bottomPanel.add(
                refreshButton
        );

        bottomPanel.add(
                backButton
        );


        add(
                bottomPanel,
                BorderLayout.SOUTH
        );


        // BUTTON DESIGN

        JButton[] buttons = {

                refreshButton,
                backButton

        };


        for (JButton button : buttons) {

            button.setBackground(
                    new Color(
                            45,
                            95,
                            88
                    )
            );

            button.setForeground(
                    Color.WHITE
            );

            button.setFocusPainted(
                    false
            );

            button.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            15
                    )
            );

        }


        // REFRESH BUTTON

        refreshButton.addActionListener(e -> {

            loadMaintenance();

        });


        // BACK BUTTON

        backButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "Maintenance"
            );

        });


        // LOAD DATA

        loadMaintenance();

    }


    public void loadMaintenance() {

        try {

            model.setRowCount(0);


            Connection connection =
                    DBConnection.getConnection();


            String query =
                    "SELECT * FROM maintenance";


            PreparedStatement statement =
                    connection.prepareStatement(
                            query
                    );


            ResultSet result =
                    statement.executeQuery();


            while (result.next()) {

                model.addRow(
                        new Object[]{

                                result.getInt("id"),

                                result.getInt(
                                        "equipment_id"
                                ),

                                result.getString(
                                        "maintenance_date"
                                ),

                                result.getString(
                                        "description"
                                ),

                                result.getString(
                                        "status"
                                )

                        }
                );

            }


            connection.close();


        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error: " +
                            ex.getMessage()
            );

        }

    }

}