package pages;

import javax.swing.*;
import java.awt.*;

public class EquipmentPanel extends JPanel {

    CardLayout cardLayout;
    JPanel contentPanel;

    public EquipmentPanel(
            CardLayout cardLayout,
            JPanel contentPanel
    ) {

        this.cardLayout = cardLayout;
        this.contentPanel = contentPanel;

        setLayout(null);

        setBackground(
                new Color(245, 247, 246)
        );


        JLabel title =
                new JLabel(
                        "EQUIPMENT MANAGEMENT"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30
                )
        );

        title.setBounds(
                330,
                180,
                500,
                50
        );

        add(title);


        JButton addButton =
                new JButton(
                        "Add Equipment"
                );

        addButton.setBounds(
                250,
                280,
                200,
                50
        );


        JButton viewButton =
                new JButton(
                        "View Equipment"
                );

        viewButton.setBounds(
                500,
                280,
                200,
                50
        );


        JButton updateButton =
                new JButton(
                        "Update Equipment"
                );

        updateButton.setBounds(
                250,
                360,
                200,
                50
        );


        JButton deleteButton =
                new JButton(
                        "Delete Equipment"
                );

        deleteButton.setBounds(
                500,
                360,
                200,
                50
        );


        add(addButton);

        add(viewButton);

        add(updateButton);

        add(deleteButton);


        JButton[] buttons = {

                addButton,
                viewButton,
                updateButton,
                deleteButton

        };


        for (JButton button : buttons) {

            button.setBackground(
                    new Color(
                            45,
                            95,
                            88
                    )
            );

            button.setForeground(
                    Color.WHITE
            );

            button.setFocusPainted(
                    false
            );

            button.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            15
                    )
            );

        }


        // ADD EQUIPMENT

        addButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "addEquipment"
            );

        });


        // VIEW EQUIPMENT

        viewButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "viewEquipment"
            );

        });


        // UPDATE EQUIPMENT

        updateButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "updateEquipment"
            );

        });


        // DELETE EQUIPMENT

        deleteButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "deleteEquipment"
            );

        });

    }

}