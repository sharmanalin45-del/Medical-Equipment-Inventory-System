package pages;

import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class ForgotPasswordPage extends JFrame {

    JTextField usernameField;
    JPasswordField newPasswordField;
    JPasswordField confirmPasswordField;

    JButton resetButton;
    JButton backButton;

    public ForgotPasswordPage() {

        setTitle("Medical Equipment Inventory System - Forgot Password");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(null);


        JLabel title = new JLabel("RESET PASSWORD");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(160, 40, 250, 30);
        add(title);


        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(90, 120, 100, 30);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(200, 120, 200, 30);
        add(usernameField);


        JLabel newPasswordLabel = new JLabel("New Password:");
        newPasswordLabel.setBounds(90, 170, 100, 30);
        add(newPasswordLabel);

        newPasswordField = new JPasswordField();
        newPasswordField.setBounds(200, 170, 200, 30);
        add(newPasswordField);


        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setBounds(70, 220, 130, 30);
        add(confirmPasswordLabel);

        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setBounds(200, 220, 200, 30);
        add(confirmPasswordField);


        resetButton = new JButton("Reset Password");
        resetButton.setBounds(100, 300, 140, 40);
        add(resetButton);


        backButton = new JButton("Back to Login");
        backButton.setBounds(260, 300, 130, 40);
        add(backButton);


        resetButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                try {

                    String username = usernameField.getText();

                    String newPassword =
                            new String(newPasswordField.getPassword());

                    String confirmPassword =
                            new String(confirmPasswordField.getPassword());


                    if (username.isEmpty() ||
                            newPassword.isEmpty() ||
                            confirmPassword.isEmpty()) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Please fill all fields"
                        );

                    } else if (!newPassword.equals(confirmPassword)) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Passwords do not match"
                        );

                    } else {

                        Connection connection =
                                DBConnection.getConnection();

                        String query =
                                "UPDATE users SET password=? WHERE username=?";

                        PreparedStatement statement =
                                connection.prepareStatement(query);

                        statement.setString(1, newPassword);
                        statement.setString(2, username);

                        int result = statement.executeUpdate();


                        if (result > 0) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Password Reset Successfully!"
                            );

                            new LoginPage();

                            dispose();

                        } else {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Username not found"
                            );

                        }


                        connection.close();

                    }

                } catch (Exception ex) {

                    JOptionPane.showMessageDialog(
                            null,
                            ex.getMessage()
                    );

                }

            }

        });


        backButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                new LoginPage();

                dispose();

            }

        });


        setVisible(true);
    }


    public static void main(String[] args) {

        new ForgotPasswordPage();

    }
}