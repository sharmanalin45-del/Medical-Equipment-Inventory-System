package pages;

import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UpdateEquipmentPage extends JPanel {

    JTextField idField;
    JTextField nameField;
    JTextField categoryField;
    JTextField quantityField;
    JTextField priceField;
    JTextField supplierField;

    JButton searchButton;
    JButton updateButton;
    JButton backButton;

    CardLayout cardLayout;
    JPanel contentPanel;


    public UpdateEquipmentPage(
            CardLayout cardLayout,
            JPanel contentPanel
    ) {

        this.cardLayout = cardLayout;
        this.contentPanel = contentPanel;

        setLayout(null);

        setBackground(
                new Color(245, 247, 246)
        );


        // TITLE

        JLabel title =
                new JLabel("UPDATE EQUIPMENT");

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        title.setBounds(
                330,
                80,
                350,
                50
        );

        add(title);


        // EQUIPMENT ID

        JLabel idLabel =
                new JLabel("Equipment ID:");

        idLabel.setBounds(
                200,
                150,
                120,
                30
        );

        add(idLabel);


        idField =
                new JTextField();

        idField.setBounds(
                340,
                150,
                150,
                30
        );

        add(idField);


        // SEARCH BUTTON

        searchButton =
                new JButton("Search");

        searchButton.setBounds(
                510,
                150,
                100,
                30
        );

        add(searchButton);


        // EQUIPMENT NAME

        JLabel nameLabel =
                new JLabel("Equipment Name:");

        nameLabel.setBounds(
                200,
                200,
                120,
                30
        );

        add(nameLabel);


        nameField =
                new JTextField();

        nameField.setBounds(
                340,
                200,
                270,
                30
        );

        add(nameField);


        // CATEGORY

        JLabel categoryLabel =
                new JLabel("Category:");

        categoryLabel.setBounds(
                200,
                250,
                120,
                30
        );

        add(categoryLabel);


        categoryField =
                new JTextField();

        categoryField.setBounds(
                340,
                250,
                270,
                30
        );

        add(categoryField);


        // QUANTITY

        JLabel quantityLabel =
                new JLabel("Quantity:");

        quantityLabel.setBounds(
                200,
                300,
                120,
                30
        );

        add(quantityLabel);


        quantityField =
                new JTextField();

        quantityField.setBounds(
                340,
                300,
                270,
                30
        );

        add(quantityField);


        // PRICE

        JLabel priceLabel =
                new JLabel("Price:");

        priceLabel.setBounds(
                200,
                350,
                120,
                30
        );

        add(priceLabel);


        priceField =
                new JTextField();

        priceField.setBounds(
                340,
                350,
                270,
                30
        );

        add(priceField);


        // SUPPLIER

        JLabel supplierLabel =
                new JLabel("Supplier:");

        supplierLabel.setBounds(
                200,
                400,
                120,
                30
        );

        add(supplierLabel);


        supplierField =
                new JTextField();

        supplierField.setBounds(
                340,
                400,
                270,
                30
        );

        add(supplierField);


        // UPDATE BUTTON

        updateButton =
                new JButton(
                        "Update Equipment"
                );

        updateButton.setBounds(
                280,
                480,
                170,
                45
        );

        add(updateButton);


        // BACK BUTTON

        backButton =
                new JButton("Back");

        backButton.setBounds(
                470,
                480,
                120,
                45
        );

        add(backButton);


        // BUTTON DESIGN

        JButton[] buttons = {

                searchButton,
                updateButton,
                backButton

        };


        for (JButton button : buttons) {

            button.setBackground(
                    new Color(
                            45,
                            95,
                            88
                    )
            );

            button.setForeground(
                    Color.WHITE
            );

            button.setFocusPainted(
                    false
            );

            button.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            14
                    )
            );

        }


        // =========================
        // SEARCH BUTTON
        // =========================

        searchButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent e
                    ) {

                        try {

                            int id =
                                    Integer.parseInt(
                                            idField.getText()
                                    );


                            Connection connection =
                                    DBConnection.getConnection();


                            String query =
                                    "SELECT * FROM equipment WHERE id=?";


                            PreparedStatement statement =
                                    connection.prepareStatement(
                                            query
                                    );


                            statement.setInt(
                                    1,
                                    id
                            );


                            ResultSet result =
                                    statement.executeQuery();


                            if (result.next()) {

                                nameField.setText(
                                        result.getString(
                                                "name"
                                        )
                                );


                                categoryField.setText(
                                        result.getString(
                                                "category"
                                        )
                                );


                                quantityField.setText(
                                        String.valueOf(
                                                result.getInt(
                                                        "quantity"
                                                )
                                        )
                                );


                                priceField.setText(
                                        String.valueOf(
                                                result.getDouble(
                                                        "price"
                                                )
                                        )
                                );


                                supplierField.setText(
                                        result.getString(
                                                "supplier"
                                        )
                                );


                            } else {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Equipment Not Found"
                                );

                            }


                            connection.close();


                        } catch (Exception ex) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Error: "
                                            + ex.getMessage()
                            );

                        }

                    }

                }
        );


        // =========================
        // UPDATE BUTTON
        // =========================

        updateButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent e
                    ) {

                        try {

                            Connection connection =
                                    DBConnection.getConnection();


                            String query =
                                    "UPDATE equipment SET name=?, category=?, quantity=?, price=?, supplier=? WHERE id=?";


                            PreparedStatement statement =
                                    connection.prepareStatement(
                                            query
                                    );


                            statement.setString(
                                    1,
                                    nameField.getText()
                            );


                            statement.setString(
                                    2,
                                    categoryField.getText()
                            );


                            statement.setInt(
                                    3,
                                    Integer.parseInt(
                                            quantityField.getText()
                                    )
                            );


                            statement.setDouble(
                                    4,
                                    Double.parseDouble(
                                            priceField.getText()
                                    )
                            );


                            statement.setString(
                                    5,
                                    supplierField.getText()
                            );


                            statement.setInt(
                                    6,
                                    Integer.parseInt(
                                            idField.getText()
                                    )
                            );


                            int rows =
                                    statement.executeUpdate();


                            if (rows > 0) {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Equipment Updated Successfully!"
                                );


                            } else {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Equipment Not Found"
                                );

                            }


                            connection.close();


                        } catch (Exception ex) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    "Error: "
                                            + ex.getMessage()
                            );

                        }

                    }

                }
        );


        // =========================
        // BACK BUTTON
        // =========================

        backButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "Equipment"
            );

        });

    }

}