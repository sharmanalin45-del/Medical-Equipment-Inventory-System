package pages;

import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class SignUpPage extends JFrame {

    JTextField usernameField;
    JPasswordField passwordField;
    JPasswordField confirmPasswordField;

    JButton signUpButton;
    JButton backButton;

    public SignUpPage() {

        setTitle("Medical Equipment Inventory System - Sign Up");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(null);


        JLabel title = new JLabel("CREATE NEW ACCOUNT");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(130, 40, 300, 30);
        add(title);


        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(90, 120, 100, 30);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(200, 120, 200, 30);
        add(usernameField);


        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(90, 170, 100, 30);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(200, 170, 200, 30);
        add(passwordField);


        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setBounds(70, 220, 130, 30);
        add(confirmPasswordLabel);

        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setBounds(200, 220, 200, 30);
        add(confirmPasswordField);


        signUpButton = new JButton("Sign Up");
        signUpButton.setBounds(120, 300, 120, 40);
        add(signUpButton);


        backButton = new JButton("Back to Login");
        backButton.setBounds(260, 300, 130, 40);
        add(backButton);


        signUpButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                try {

                    String username = usernameField.getText();

                    String password =
                            new String(passwordField.getPassword());

                    String confirmPassword =
                            new String(confirmPasswordField.getPassword());


                    if (username.isEmpty() ||
                            password.isEmpty() ||
                            confirmPassword.isEmpty()) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Please fill all fields"
                        );

                    } else if (!password.equals(confirmPassword)) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Passwords do not match"
                        );

                    } else {

                        Connection connection =
                                DBConnection.getConnection();

                        String query =
                                "INSERT INTO users VALUES (?, ?)";

                        PreparedStatement statement =
                                connection.prepareStatement(query);

                        statement.setString(1, username);
                        statement.setString(2, password);

                        statement.executeUpdate();

                        JOptionPane.showMessageDialog(
                                null,
                                "Account Created Successfully!"
                        );

                        new LoginPage();

                        dispose();

                        connection.close();

                    }

                } catch (Exception ex) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Username already exists or error occurred"
                    );

                }

            }

        });


        backButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                new LoginPage();

                dispose();

            }

        });


        setVisible(true);
    }


    public static void main(String[] args) {

        new SignUpPage();

    }
}