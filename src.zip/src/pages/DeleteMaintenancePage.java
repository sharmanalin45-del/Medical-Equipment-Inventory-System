package pages;

import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class DeleteMaintenancePage extends JFrame {

    public DeleteMaintenancePage(String role) {

        setTitle("Delete Maintenance");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);


        JLabel title =
                new JLabel("DELETE MAINTENANCE RECORD");

        title.setFont(
                new Font("Arial", Font.BOLD, 22)
        );

        title.setBounds(
                150, 40, 350, 40
        );


        JLabel idLabel =
                new JLabel("Maintenance ID:");

        idLabel.setBounds(
                120, 130, 130, 30
        );


        JTextField idField =
                new JTextField();

        idField.setBounds(
                260, 130, 200, 30
        );


        JButton deleteButton =
                new JButton("Delete");

        deleteButton.setBounds(
                180, 210, 120, 40
        );


        JButton backButton =
                new JButton("Back");

        backButton.setBounds(
                330, 210, 120, 40
        );


        panel.add(title);

        panel.add(idLabel);
        panel.add(idField);

        panel.add(deleteButton);
        panel.add(backButton);


        deleteButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(
                            ActionEvent e) {

                        try {

                            Connection connection =
                                    DBConnection.getConnection();


                            String query =
                                    "DELETE FROM maintenance " +
                                            "WHERE maintenance_id=?";


                            PreparedStatement statement =
                                    connection.prepareStatement(query);


                            statement.setInt(
                                    1,
                                    Integer.parseInt(
                                            idField.getText()
                                    )
                            );


                            int rows =
                                    statement.executeUpdate();


                            if (rows > 0) {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Maintenance Record Deleted Successfully!"
                                );

                                idField.setText("");

                            } else {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Maintenance ID Not Found!"
                                );

                            }


                            connection.close();


                        } catch (Exception ex) {

                            JOptionPane.showMessageDialog(
                                    null,
                                    ex.getMessage()
                            );

                        }

                    }

                }
        );


        backButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                cardLayout.show(
                        contentPanel,
                        "Maintenance"
                );

            }

        });


        add(panel);

        setVisible(true);
    }
}