package pages;

import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class DeleteEquipmentPage extends JPanel {

    CardLayout cardLayout;
    JPanel contentPanel;

    JTextField idField;

    JButton deleteButton;
    JButton backButton;

    public DeleteEquipmentPage(
            CardLayout cardLayout,
            JPanel contentPanel
    ) {

        this.cardLayout = cardLayout;
        this.contentPanel = contentPanel;

        setLayout(null);

        setBackground(
                new Color(245, 247, 246)
        );


        JLabel title =
                new JLabel(
                        "DELETE EQUIPMENT"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30
                )
        );

        title.setBounds(
                350,
                150,
                400,
                50
        );

        add(title);


        JLabel idLabel =
                new JLabel(
                        "Equipment ID:"
                );

        idLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        16
                )
        );

        idLabel.setBounds(
                300,
                250,
                150,
                30
        );

        add(idLabel);


        idField =
                new JTextField();

        idField.setBounds(
                430,
                250,
                200,
                35
        );

        add(idField);


        deleteButton =
                new JButton(
                        "Delete Equipment"
                );

        deleteButton.setBounds(
                330,
                330,
                160,
                45
        );

        add(deleteButton);


        backButton =
                new JButton(
                        "Back"
                );

        backButton.setBounds(
                510,
                330,
                100,
                45
        );

        add(backButton);


        JButton[] buttons = {

                deleteButton,
                backButton

        };


        for (JButton button : buttons) {

            button.setBackground(
                    new Color(
                            45,
                            95,
                            88
                    )
            );

            button.setForeground(
                    Color.WHITE
            );

            button.setFocusPainted(
                    false
            );

            button.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            14
                    )
            );

        }


        // DELETE EQUIPMENT BUTTON

        deleteButton.addActionListener(e -> {

            try {

                if (
                        idField.getText()
                                .trim()
                                .isEmpty()
                ) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Please enter Equipment ID"
                    );

                    return;

                }


                int id =
                        Integer.parseInt(
                                idField
                                        .getText()
                                        .trim()
                        );


                int choice =
                        JOptionPane.showConfirmDialog(
                                this,
                                "Are you sure you want to delete this equipment?",
                                "Confirm Delete",
                                JOptionPane.YES_NO_OPTION
                        );


                if (
                        choice
                                != JOptionPane.YES_OPTION
                ) {

                    return;

                }


                Connection connection =
                        DBConnection.getConnection();


                String query =
                        "DELETE FROM equipment WHERE id=?";


                PreparedStatement statement =
                        connection.prepareStatement(
                                query
                        );


                statement.setInt(
                        1,
                        id
                );


                int rows =
                        statement.executeUpdate();


                if (
                        rows > 0
                ) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Equipment Deleted Successfully!"
                    );

                    idField.setText("");

                }

                else {

                    JOptionPane.showMessageDialog(
                            this,
                            "Equipment Not Found"
                    );

                }


                statement.close();

                connection.close();

            }

            catch (NumberFormatException ex) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter a valid Equipment ID"
                );

            }

            catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        this,
                        "Error: "
                                + ex.getMessage()
                );

            }

        });


        // BACK BUTTON

        backButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "Equipment"
            );

        });

    }

}