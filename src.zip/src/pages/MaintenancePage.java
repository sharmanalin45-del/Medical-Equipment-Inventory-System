package pages;

import javax.swing.*;
import java.awt.*;

public class MaintenancePage extends JPanel {

    CardLayout cardLayout;
    JPanel contentPanel;

    public MaintenancePage(
            CardLayout cardLayout,
            JPanel contentPanel
    ) {

        this.cardLayout = cardLayout;
        this.contentPanel = contentPanel;

        setLayout(null);

        setBackground(
                new Color(
                        245,
                        247,
                        246
                )
        );


        JLabel title =
                new JLabel(
                        "MAINTENANCE MANAGEMENT"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30
                )
        );

        title.setBounds(
                300,
                180,
                500,
                50
        );

        add(title);


        JButton addButton =
                new JButton(
                        "Add Maintenance"
                );

        addButton.setBounds(
                250,
                280,
                200,
                50
        );


        JButton viewButton =
                new JButton(
                        "View Maintenance"
                );

        viewButton.setBounds(
                500,
                280,
                200,
                50
        );


        JButton deleteButton =
                new JButton(
                        "Delete Maintenance"
                );

        deleteButton.setBounds(
                375,
                360,
                200,
                50
        );


        add(addButton);

        add(viewButton);

        add(deleteButton);


        JButton[] buttons = {

                addButton,
                viewButton,
                deleteButton

        };


        for (JButton button : buttons) {

            button.setBackground(
                    new Color(
                            45,
                            95,
                            88
                    )
            );

            button.setForeground(
                    Color.WHITE
            );

            button.setFocusPainted(
                    false
            );

            button.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            15
                    )
            );

        }


        // ADD MAINTENANCE

        addButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "addMaintenance"
            );

        });


        // VIEW MAINTENANCE

        viewButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "viewMaintenance"
            );

        });


        // DELETE MAINTENANCE

        deleteButton.addActionListener(e -> {

            cardLayout.show(
                    contentPanel,
                    "deleteMaintenance"
            );

        });

    }

}